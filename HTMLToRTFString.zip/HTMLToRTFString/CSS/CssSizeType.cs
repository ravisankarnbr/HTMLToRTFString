﻿namespace HTMLToRTFString.Css
{
    internal enum CssSizeType { In, Px, Pt, Pc }
}