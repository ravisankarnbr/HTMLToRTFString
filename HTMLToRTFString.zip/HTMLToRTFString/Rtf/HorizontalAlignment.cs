﻿namespace HTMLToRTFString.Rtf
{
    public enum HorizontalAlignment
    {
        Left,
        Center,
        Right,
        Justify
    }
}