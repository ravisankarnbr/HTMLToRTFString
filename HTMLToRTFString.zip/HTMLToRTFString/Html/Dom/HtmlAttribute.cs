﻿namespace HTMLToRTFString.Html.Dom
{
    public class HtmlAttribute
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}