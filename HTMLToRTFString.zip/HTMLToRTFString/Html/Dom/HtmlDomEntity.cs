﻿namespace HTMLToRTFString.Html.Dom
{
    public abstract class HtmlDomEntity { }
}