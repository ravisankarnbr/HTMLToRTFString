﻿namespace HTMLToRTFString.Html.Dom
{
    public class HtmlComment : HtmlDomEntity
    {
        public string Value { get; set; } = string.Empty;
    }
}
