﻿namespace HTMLToRTFString.Html.Dom
{
    public class HtmlText : HtmlDomEntity
    {
        public string Text { get; set; }
    }

}
